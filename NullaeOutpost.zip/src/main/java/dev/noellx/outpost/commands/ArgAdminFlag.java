/*
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package dev.noellx.outpost.commands;

import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;

import dev.noellx.outpost.FlagHandler;
import dev.noellx.outpost.NOL;
import dev.noellx.outpost.NORegion;
import dev.noellx.outpost.NullaeOutpost;
import dev.noellx.outpost.utils.UUIDCache;
import dev.noellx.outpost.utils.WGUtils;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.CommandSender;

class ArgAdminFlag {
    static boolean argumentAdminFlag(CommandSender p, String[] args) {

        if (args.length < 5) {
            NOL.msg(p, ArgAdmin.getFlagHelp());
            return true;
        }

        String flag, value = "", gee = "";
        World w = Bukkit.getWorld(args[2]);
        if (w == null)
            return NOL.msg(p, NOL.INVALID_WORLD.msg());

        if (args[3].equalsIgnoreCase("-g")) {
            flag = args[5];
            for (int i = 6; i < args.length; i++) value += args[i] + " ";
            gee = args[4];
        } else {
            flag = args[3];
            for (int i = 4; i < args.length; i++) value += args[i] + " ";
        }

        if (WGUtils.getFlagRegistry().get(flag) == null)
            return NOL.msg(p, NOL.FLAG_NOT_SET.msg());

        final String fValue = value, fGee = gee;
        RegionManager rgm = WGUtils.getRegionManagerWithWorld(w);
        for (ProtectedRegion r : rgm.getRegions().values()) {
            if (NullaeOutpost.isNORegion(r) && NORegion.fromWGRegion(w, r) != null) {
                String flagValue = fValue;

                // apply %player% placeholder
                if (FlagHandler.getPlayerPlaceholderFlags().contains(flag) && (!r.getOwners().getUniqueIds().isEmpty())) {
                    String name = UUIDCache.getNameFromUUID(r.getOwners().getUniqueIds().stream().findFirst().get());
                    if (name != null) {
                        flagValue = flagValue.replace("%player%", name);
                    }
                }

                ArgFlag.setFlag(NORegion.fromWGRegion(w, r), p, flag, flagValue.trim(), fGee);
            }
        }
        return true;
    }
}
